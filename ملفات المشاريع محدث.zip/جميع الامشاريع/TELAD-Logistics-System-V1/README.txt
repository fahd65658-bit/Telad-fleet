
TELAD Logistics Operations System V1

طريقة التشغيل:

1) تأكد أن Python مثبت على الكمبيوتر.
2) فك ضغط الملف.
3) شغل الملف:
RUN_SYSTEM.bat

سيتم فتح النظام مباشرة.

قاعدة البيانات:
database/telad.db
