
const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

app.get('/api/status', (req,res)=>{
  res.json({system:"TELAD Fleet",status:"running"})
});

app.listen(port, ()=>{
 console.log("TELAD Fleet server running on port "+port);
});
